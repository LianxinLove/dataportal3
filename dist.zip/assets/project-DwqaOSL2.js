import{aa as e}from"./index-Dvgg5_tE.js";const r=e("project",{state:()=>({project:{}}),actions:{setProject(t){console.log("setProject",t),this.project=t.project}},persist:!0});export{r as u};
