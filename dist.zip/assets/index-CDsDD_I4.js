import{_ as o,l as r,f as n,o as t}from"./index-Dvgg5_tE.js";const c={};function s(_,a){const e=r("router-view");return t(),n(e)}const i=o(c,[["render",s]]);export{i as default};
