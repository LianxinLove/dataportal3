import{aa as t}from"./index-Dvgg5_tE.js";const s=t("tool",{state:()=>({tool:{}}),actions:{setTool(o){this.tool=o.tool}},persist:!0});export{s as u};
